INSERT INTO Customers (CustomerID, CustomerName, Customeraddress, Customerpaymenttype, Customerpaymentmethod, Dateofmembershipstart, Pettype)
VALUES ('1', 'Owen Shaw', '1 example st', 'Payment plan', 'Debit', '12/11/2020', 'cat');
INSERT INTO Customers (CustomerID, CustomerName, Customeraddress, Customerpaymenttype, Customerpaymentmethod, Dateofmembershipstart, Pettype)
VALUES ('2', 'John smith', '2 example st', 'Payment plan', 'Debit', '12/11/2020', 'Dog');
INSERT INTO Customers (CustomerID, CustomerName, Customeraddress, Customerpaymenttype, Customerpaymentmethod, Dateofmembershipstart, Pettype)
VALUES ('3', 'Tom Scott', '5 example st', 'Payment plan', 'Debit', '12/11/2020', 'cat');
INSERT INTO Customers (CustomerID, CustomerName, Customeraddress, Customerpaymenttype, Customerpaymentmethod, Dateofmembershipstart, Pettype)
VALUES ('4', 'Debby Mills', '3 example st', 'Payment plan', 'Debit', '12/11/2020', 'Cat');
INSERT INTO Customers (CustomerID, CustomerName, Customeraddress, Customerpaymenttype, Customerpaymentmethod, Dateofmembershipstart, Pettype)
VALUES ('5', 'Danny Thomas', '4 example st', 'Payment plan', 'Debit', '12/11/2020', 'Cat');