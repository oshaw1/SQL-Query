SELECT * FROM Customers
WHERE Pettype = "cat";
